# Screenshot checklist

Add sanitized screenshots of:
1. Resource group listing (`rg-az104-lab01`).
2. IAM built-in role list (Owner, Contributor, Reader).
3. Microsoft Entra access-denied page (redact identifiers).
4. `Protect-AZ` Delete lock on the resource group.

Do not upload unredacted portal screenshots to a public repository.
