# AZ-104 Lab 01 — Azure Resource Governance and Access Control

**Status:** In progress  
**Platform:** Microsoft Azure for Students  
**Environment:** Educational lab (ECPI-associated tenant)  
**Exam alignment:** AZ-104 — Manage Azure identities and governance

## Objective
Practice organizing and protecting Azure resources, inspect role-based access control (RBAC), and document access limitations encountered in a managed Microsoft Entra tenant.

## Activities and evidence

| Activity | Status | Evidence / notes |
|---|---|---|
| Create resource group `rg-az104-lab01` | Completed | Resource groups listing screenshot |
| Configure resource tags | Not yet verified | Check Tags blade and capture evidence |
| Review Owner, Contributor, and Reader Azure roles | Completed | IAM roles screenshot |
| Open Microsoft Entra ID | Attempted; access denied | 401 access-denied screenshot; directory identified as ECPI |
| Create resource group Delete lock (`Protect-AZ`) | Completed | Locks blade screenshot |
| Remove lock after exercise | Not yet confirmed | Verify before cleanup |
| Create Entra security group / assign Reader | Not completed | Blocked pending directory access and role-assignment permissions |

## What I did
1. Signed into the Azure portal using an Azure for Students subscription.
2. Created `rg-az104-lab01` to organize lab resources.
3. Opened **Access control (IAM)** and inspected the built-in **Owner**, **Contributor**, and **Reader** roles.
4. Attempted to access Microsoft Entra ID and received a **401 — You don't have access** message. Confirmed that the selected directory was associated with ECPI; the exact cause and permissions must be verified by an administrator.
5. Created a **Delete (CanNotDelete)** management lock named `Protect-AZ` on the resource group to guard against accidental deletion.

## Concepts demonstrated
- **Resource groups:** Logical containers and management scopes for Azure resources.
- **Azure RBAC:** Assigns permissions to principals at a scope, such as a resource group.
- **Microsoft Entra ID vs. Azure RBAC:** Directory permissions are separate from Azure resource permissions.
- **Management locks:** A Delete lock prevents deletion of the locked scope and inherited resources, but does not prevent authorized modifications.
- **Troubleshooting:** A 401 access error is evidence of denied access, not proof of the exact tenant policy or missing role.

## Validation and next steps
- [ ] Confirm the resource group's tags.
- [ ] Record any role assignments visible under **IAM → Role assignments**.
- [ ] Confirm the `Protect-AZ` lock has been removed after testing.
- [ ] Continue with virtual networking labs within subscription permissions and budget.
- [ ] Add sanitized screenshots to `screenshots/` and reference them below.

## Screenshots
The following screenshots are cropped to exclude browser address bars and visible account identifiers. They document the work performed, not completed steps that remain pending.

![Resource group created](screenshots/01-resource-group-created.png)

*Figure 1. Azure for Students resource group created.*

![RBAC roles reviewed](screenshots/02-rbac-roles-reviewed.png)

*Figure 2. Built-in RBAC roles inspected; role assignments were not changed.*

![Entra access denied](screenshots/03-entra-access-denied.png)

*Figure 3. Entra ID access-denied message encountered during identity lab.*

![Delete lock created](screenshots/04-delete-lock-created.png)

*Figure 4. Delete lock created to protect the resource group.*

## Reflection
This lab showed that access to Azure resources does not automatically grant permission to administer Microsoft Entra ID. It also introduced resource governance and safeguards used in real administration workflows.

> This is a personal learning project. It does not document any employer or Department of Defense production environment.
