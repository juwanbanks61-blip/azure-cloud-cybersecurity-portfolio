# Lab 01 screenshot evidence

These are cropped copies of screenshots captured during the lab. Browser address bars and visible account identifiers have been excluded. Review images again before publishing publicly.

1. `01-resource-group-created.png` — Resource group listed under Azure for Students.
2. `02-rbac-roles-reviewed.png` — Built-in Azure RBAC roles viewed; no role assignment claimed.
3. `03-entra-access-denied.png` — Microsoft Entra ID access-denied screen.
4. `04-delete-lock-created.png` — `Protect-AZ` Delete lock created on resource group.
