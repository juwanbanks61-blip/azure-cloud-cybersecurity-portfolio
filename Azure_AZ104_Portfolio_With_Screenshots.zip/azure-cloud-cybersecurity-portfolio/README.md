# Azure Cloud & Cybersecurity Portfolio

Hands-on Microsoft Azure administration and security labs focused on AZ-104 exam preparation and practical cloud operations.

## Projects

| Project | Focus | Status |
|---|---|---|
| [Lab 01 — Azure Resource Governance and Access Control](01-azure-governance/README.md) | Resource groups, RBAC, Entra access troubleshooting, management locks | In progress |

## Approach
Each lab documents objectives, implementation, validation, troubleshooting, and lessons learned. Completed tasks are distinguished from planned or blocked activities.

## Safety
Screenshots and documentation are sanitized before publication. No credentials, subscription or tenant identifiers, customer data, or employer/DoD infrastructure information are included.
